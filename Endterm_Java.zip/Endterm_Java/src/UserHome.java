package classes;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

public class UserHome extends JFrame{
	 private static final long serialVersionUID = 1L;
	 private JPanel contentPane;
	 DatabaseInterface show = new ApplicationFunctions();
	 
	 public UserHome() {

	    }

	    /**
	     * Create the frame.
	     */
	    public UserHome(String userSes) {

	        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        setBounds(450, 190, 1014, 597);
	        setResizable(false);
	        contentPane = new JPanel();
	        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	        setContentPane(contentPane);
	        contentPane.setLayout(null);
	        JButton btnNewButton = new JButton("Logout");
	        btnNewButton.setForeground(new Color(0, 0, 0));
	        btnNewButton.setBackground(UIManager.getColor("Button.disabledForeground"));
	        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 39));
	        btnNewButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	try {
	                    Connection connection = (Connection) DriverManager.getConnection("jdbc:postgresql://localhost:5432/MenuCafe",
	                        "postgres", "asimok373");

	                    PreparedStatement st = (PreparedStatement) connection
	                        .prepareStatement("Select * from MenuCoffee");
	                    ResultSet rs = st.executeQuery();}
	                    catch (SQLException e) {
	    		            e.printStackTrace();
	    		        }
	                int a = JOptionPane.showConfirmDialog(btnNewButton, "Are you sure?");
	                // JOptionPane.setRootFrame(null);
	                if (a == JOptionPane.YES_OPTION) {
	                    dispose();
	                    Application obj = new Application();
	                    obj.setTitle("Client-Login");
	                    obj.setVisible(true);
	                }
	                dispose();
	                Application obj = new Application();

	                obj.setTitle("Client-Login");
	                obj.setVisible(true);

	            }
	        });
	        btnNewButton.setBounds(247, 118, 491, 114);
	        contentPane.add(btnNewButton);
	        JButton button = new JButton("Change-password\r\n");
	        button.setBackground(UIManager.getColor("Button.disabledForeground"));
	        button.setFont(new Font("Tahoma", Font.PLAIN, 35));
	        button.setBounds(247, 320, 491, 114);
	        contentPane.add(button);
	    }
}
