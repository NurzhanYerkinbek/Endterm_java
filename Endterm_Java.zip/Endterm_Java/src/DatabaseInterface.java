package classes;

public interface DatabaseInterface {
	public void getData();
}