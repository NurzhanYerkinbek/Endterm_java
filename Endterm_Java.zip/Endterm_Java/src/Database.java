package classes;

import java.sql.*;

public class Database {
    private final String DB_URL = "jdbc:postgresql://localhost:5432/Food";
    private final String USER = "postgres";
    private final String PASS = "asimok373";
	 
    public void connect() {
    	try(Connection connection = DriverManager.getConnection(DB_URL, USER, PASS)) {
    		if(connection != null) {
    			System.out.println("Connected to BD");
    		} else {
    			System.out.println("Failed to connect BD");
    		}
    	} catch (SQLException e) {
    		e.printStackTrace();
    	}
    }
    
}
