package endterm;

public class Main {
    public static void main(String[] args) {
        toLookAll example = new toLookAll();
    }
}
