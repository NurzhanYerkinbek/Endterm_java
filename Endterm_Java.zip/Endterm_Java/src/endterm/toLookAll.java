package endterm;
import java.sql.*;
public class toLookAll {
    String connectionUrl="jdbc:postgresql://localhost:5432/postgres";
    Connection con;
    ResultSet res;
    Statement stmt ;
    public toLookAll(){
        try
        {
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(connectionUrl,"postgres","Nurzhan2002");
            stmt = con.createStatement();
            res = stmt.executeQuery("select * from coffie");
            while(res.next())
            {
                System.out.println(res.getInt("id") + " " + res.getString("name") + " " + res.getString("size") + " " + res.getInt("price"));
            }
        }
        catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

    }
}
