package classes;

import java.sql.*;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

public class ApplicationFunctions implements DatabaseInterface {

	@Override
	public void getData() {
		    String connectionUrl="jdbc:postgresql://localhost:5432/MenuCafe";
		    Connection con;
		    ResultSet res;
		    Statement stmt;
		        try
		        {
		            Class.forName("org.postgresql.Driver");
		            con = DriverManager.getConnection(connectionUrl,"postgres","asimok373");
		            stmt = con.createStatement();
		            res = stmt.executeQuery("select * from MenuCoffee");
		            while(res.next())
		            {
		                System.out.println(res.getInt("id") + " " + res.getString("name") + " " + res.getInt("price"));
		            }
		        }
		        catch (ClassNotFoundException e)
		        {
		            e.printStackTrace();
		        }
		        catch (SQLException e) {
		            e.printStackTrace();
		        }
	}

	
	
}
