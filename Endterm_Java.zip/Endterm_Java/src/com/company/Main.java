package com.company;
import java.util.Scanner;

public class Main extends pattern {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Main m = new Main();
        boolean menu = true;
        boolean cof = true;
        boolean tea = true;
        while (menu) {
            m.id+=1;
            m.mainMenu();
            int choice = input.nextInt();
            switch (choice) {
                case 1:
                    menu = false;
                    m.coffeeMenu(cof);
                    menu=true;
                    System.out.println(" ");
                    break;

                case 2:
                    menu = false;
                    m.teaMenu(tea);
                    menu=true;
                    System.out.println(" ");
                    break;

                case 3:
                    menu = false;
                    break;
                default:
                    System.out.println("Please, print number have in menu\n");
                    break;
            }
        }
        System.out.print("Bye,bye!\n");
    }

    public void mainMenu(){
        System.out.println("\nProduct types   |");
        System.out.println("________________|______________________________________________________________________________");
        System.out.println("1.Coffee        |");
        System.out.println("2.Tea           |");
        System.out.println("3.To quit       |");
        System.out.println("________________|______________________________________________________________________________");
        System.out.println("                |");

        System.out.print("Enter your choice:");
    }

    public void coffeeMenu(boolean cof){
        Scanner input = new Scanner(System.in);
        System.out.println("\n\nCoffee's menu   |Small cup(1) | Big Cup(2) |");
        System.out.println("________________|_____________|____________|___________________________________________________");
        System.out.println("1.Espresso      |     390tg   |  490tg     |");
        System.out.println("2.Americano     |     590tg   |  790tg     |");
        System.out.println("3.Cappuccino    |     690tg   |  890tg     |");
        System.out.println("4.Latte         |     790tg   |  990tg     |");
        System.out.println("5.Back to menu  |             |            |");
        System.out.println("________________|_____________|____________|___________________________________________________");
        System.out.println("                |             |            |");
        System.out.print(" Choose one type of coffee:");
        while (cof) {

            int choice = input.nextInt();
            int choice2;
            switch (choice) {
                case 1:
                    System.out.println("Cup's size:");
                    choice2 = input.nextInt();
                    if(choice2==1){
                        size = "small";
                        price = 390;
                    }
                    else if(choice2==2){
                        size ="big";
                        price = 490;
                    }
                    name = "espresso";
                    toInput insert = new toInput(id,name,size,price);
                    cof = false;
                    break;

                case 2:
                    System.out.println("Cup's size:");
                    choice2 = input.nextInt();
                    if(choice2==1){
                        size = "small";
                        price = 590;
                    }
                    else if(choice2==2){
                        size ="big";
                        price = 790;
                    }
                    name = "americano";
                    insert = new toInput(id,name,size,price);
                    cof = false;
                    break;



                case 3:
                    System.out.println("Cup's size:");
                    choice2 = input.nextInt();
                    if(choice2==1){
                        size = "small";
                        price = 690;
                    }
                    else if(choice2==2){
                        size ="big";
                        price = 890;
                    }
                    name = "capuccino";
                    insert = new toInput(id,name,size,price);
                    cof = false;
                    break;



                case 4:
                    System.out.println("Cup's size:");
                    choice2 = input.nextInt();
                    if(choice2==1){
                        size = "small";
                        price = 790;
                    }
                    else if(choice2==2){
                        size ="big";
                        price = 990;
                    }
                    name = "latte";
                    insert = new toInput(id,name,size,price);
                    cof = false;
                    break;


                case 5:
                    cof = false;
                    break;

                default:
                    System.out.println("Please, print number have in menu\n");
                    break;
            }
        }


    }

    public void teaMenu(boolean cof){
        Scanner input = new Scanner(System.in);
        System.out.println("\n\n\n\nTea's menu      | Small cup(1) | Big cup(2) |Kettle(3)   |");
        System.out.println("________________|_____________|____________|____________|______________________________________");
        System.out.println("1.Black tea     |     230tg   |  310tg     |   500tg    |");
        System.out.println("2.Green tea     |     230tg   |  290tg     |   450tg    |");
        System.out.println("3.Tashkent's tea|     250tg   |  300tg     |   620tg    |");
        System.out.println("4.Moroccan tea  |     300tg   |  450tg     |   670tg    |");
        System.out.println("5.Back to menu  |             |            |            |");
        System.out.println("________________|_____________|____________|___________________________________________________");
        System.out.println("                |             |            |");
        System.out.print(" Your choice: ");
        while (cof) {

            int choice = input.nextInt();
            int choice2;
            switch (choice) {
                case 1:
                    System.out.println("Cup's size:");
                    choice2 = input.nextInt();
                    if(choice2==1){
                        size = "small";
                        price = 230;
                    }
                    else if(choice2==2){
                        size ="big";
                        price = 310;
                    }
                    else if(choice2==3){
                        size ="kettle";
                        price = 500;
                    }
                    name = "black tea";
                    toInput insert = new toInput(id,name,size,price);
                    cof = false;
                    break;


                case 2:
                    System.out.println("Cup's size:");
                    choice2 = input.nextInt();
                    if(choice2==1){
                        size = "small";
                        price = 230;
                    }
                    else if(choice2==2){
                        size ="big";
                        price = 290;
                    }
                    else if(choice2==3){
                        size ="kettle";
                        price = 450;
                    }
                    name = "green tea";
                    insert = new toInput(id,name,size,price);
                    cof = false;
                    break;



                case 3:
                    System.out.println("Cup's size:");
                    choice2 = input.nextInt();
                    if(choice2==1){
                        size = "small";
                        price = 250;
                    }
                    else if(choice2==2){
                        size ="big";
                        price = 300;
                    }
                    else if(choice2==3){
                        size ="kettle";
                        price = 620;
                    }
                    name = "tashkent tea";
                    insert = new toInput(id,name,size,price);
                    cof = false;
                    break;



                case 4:
                    System.out.println("Cup's size:");
                    choice2 = input.nextInt();
                    if(choice2==1){
                        size = "small";
                        price = 300;
                    }
                    else if(choice2==2){
                        size ="big";
                        price = 450;
                    }
                    else if(choice2==3){
                        size ="kettle";
                        price = 670;
                    }
                    name = "morokon tea";
                    insert = new toInput(id,name,size,price);
                    cof = false;
                    break;


                case 5:
                    cof = false;
                    break;

                default:
                    System.out.println("Please, print number have in menu\n");
                    break;
            }
        }
    }
}

