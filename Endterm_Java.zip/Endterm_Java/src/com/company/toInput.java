package com.company;

import java.sql.*;
public class toInput
{
    String connectionUrl="jdbc:postgresql://localhost:5432/postgres";
    Connection con;
    ResultSet insert;
    Statement stmt;
    public toInput(int id, String name, String size, int price){
        try
        {
            Class.forName("org.postgresql.Driver");// We load the driver's class file into memory at the runtime
            con = DriverManager.getConnection(connectionUrl,"postgres","Nurzhan2002"); //Establish the connection
            stmt = con.createStatement(); // The object of statement is responsible to execute with the database
            insert = stmt.executeQuery("insert into coffie(id,name ,size,price) values(" + id + ",'" + name + "','" + size + "','" + price + "')");
            //This method returns the object of ResultSet
        }
        catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (SQLException e)
        {
            //e.printStackTrace();
        }
    }
}
