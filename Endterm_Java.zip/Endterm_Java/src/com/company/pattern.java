package com.company;

public class pattern {
    int price,id;
    String name,size;
}
