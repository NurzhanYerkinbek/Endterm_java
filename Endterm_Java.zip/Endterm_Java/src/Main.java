package classes;

import java.awt.*;
import javax.swing.*;

public class Main {
	public static void main(String[] args) {
		
		
		JFrame.setDefaultLookAndFeelDecorated(true);
	       javax.swing.SwingUtilities.invokeLater(new Runnable() {
	           public void run() {
	        	   try {
	        		   Application frame = new Application();
	        		   frame.setVisible(true);
	        	   } catch (Exception e) {
	        		   e.printStackTrace();
	        	   }
	           }
	       });
	       ApplicationFunctions show = new ApplicationFunctions();
	       show.getData();
	}
}
